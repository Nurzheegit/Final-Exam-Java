package com.example.polls;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class PollsApplicationTests {

	@Test
	public void contextLoads() {
	}

}
